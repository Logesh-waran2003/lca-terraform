import boto3

def delete_s3_bucket(bucket_name):
    print(f"Emptying S3 Bucket: {bucket_name}")
    bucket = boto3.resource("s3").Bucket(bucket_name)
    bucket.object_versions.all().delete()
    print(f"All object versions deleted from {bucket_name}")

def handler(event, context):
    print(event)
    bucket_name = event.get("BucketName")
    if not bucket_name:
        raise ValueError("BucketName is required in the event payload")
    try:
        delete_s3_bucket(bucket_name)
        return {"Status": "SUCCESS", "BucketName": bucket_name}
    except Exception as e:
        print(f"Error: {e}")
        raise e
