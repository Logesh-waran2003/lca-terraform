import boto3
import json
import os
import time

connect = boto3.client('connect')
dynamodb = boto3.client('dynamodb')
kinesis = boto3.client('kinesis')

def is_known_call(callId, tablename, timeout):
    timeout_time = time.time() + int(timeout)
    while time.time() < timeout_time:
        response = dynamodb.get_item(
            TableName=tablename,
            Key={
                "PK": {"S": f"c#{callId}"},
                "SK": {"S": f"c#{callId}"}
            },
            ProjectionExpression="PK"
        )
        if "Item" in response:
            return True
        else:
            print(f"Call not found in DynamoDB - wait 1 sec and try again: {callId}")
            time.sleep(1)
    print(f"Call not found in DynamoDB after timeout period {timeout} seconds: {callId}")
    return False

def get_agentId(instanceArn, agentArn):
    if agentArn:
        response = connect.describe_user(
            UserId=agentArn,
            InstanceId=instanceArn
        )
        username = response["User"].get("Username")
        firstname = response["User"].get("IdentityInfo", {}).get("FirstName")
        lastname = response["User"].get("IdentityInfo", {}).get("LastName")
        agentId = f"{firstname} {lastname} ({username})"
        return agentId

def send_update_agent_message(streamName, callId, agentId):
    msg = {
        "CallId": callId,
        "AgentId": agentId,
        "EventType": "UPDATE_AGENT",
    }
    print(f"Writing UPDATE_AGENT message to KDS: {msg}")
    kinesis.put_record(
        StreamName=streamName,
        Data=json.dumps(msg).encode('utf-8'),
        PartitionKey=callId
    )

def handler(event, context):
    print(json.dumps(event))
    callId = event["detail"].get("contactId")
    if is_known_call(
        callId,
        os.environ["EVENT_SOURCING_TABLE_NAME"],
        os.environ["WAIT_FOR_CALL_SECS"]
    ):
        instanceArn = event["detail"].get("instanceArn")
        agentArn = event["detail"].get("agentInfo", {}).get("agentArn")
        agentId = get_agentId(instanceArn, agentArn)
        send_update_agent_message(os.environ["KINESIS_STREAM_NAME"], callId, agentId)
    else:
        print("Call not transcribing. Skipping.")
    return "Done"
