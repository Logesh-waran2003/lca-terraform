import boto3
import json

connect = boto3.client('connect')

def associateConnectInstance(connect_instance_arn, call_data_stream_arn):
    print("Associating connect instance to LCA Kinesis stream")
    response = connect.associate_instance_storage_config(
        InstanceId=connect_instance_arn,
        ResourceType="REAL_TIME_CONTACT_ANALYSIS_SEGMENTS",
        StorageConfig={
            "StorageType": "KINESIS_STREAM",
            "KinesisStreamConfig": {
                "StreamArn": call_data_stream_arn
            }
        }
    )
    print(f"associate_instance_storage_config: {response}")
    print("Configured Connect instance to integrate with LCA Kinesis Data Stream")

def disassociateConnectInstance(connect_instance_arn):
    response = connect.list_instance_storage_configs(
        InstanceId=connect_instance_arn,
        ResourceType="REAL_TIME_CONTACT_ANALYSIS_SEGMENTS"
    )
    print(f"list_instance_storage_configs: {response}")
    associationId = None
    for storageConfig in response["StorageConfigs"]:
        if storageConfig["StorageType"] == "KINESIS_STREAM":
            associationId = storageConfig["AssociationId"]
    if associationId:
        print(f"Existing storage config found. Disassociating: {associationId}")
        connect.disassociate_instance_storage_config(
            InstanceId=connect_instance_arn,
            AssociationId=associationId,
            ResourceType="REAL_TIME_CONTACT_ANALYSIS_SEGMENTS"
        )
    print("Done disassociating storage configs")

def handler(event, context):
    print(json.dumps(event))
    connect_instance_arn = event.get("ConnectInstanceArn")
    call_data_stream_arn = event.get("CallDataStreamArn")
    action = event.get("Action", "associate")
    if action == "disassociate":
        disassociateConnectInstance(connect_instance_arn)
    else:
        disassociateConnectInstance(connect_instance_arn)
        associateConnectInstance(connect_instance_arn, call_data_stream_arn)
    return {"Status": "SUCCESS"}
