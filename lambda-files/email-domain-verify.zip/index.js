exports.handler = async (event, context) => {
    console.log(event);
    const allowed_domains = (
        process.env?.ALLOWED_SIGNUP_EMAIL_DOMAINS
            .split(",")
            .map(domain => { return domain.trim() })
    );
    const { email } = event.request?.userAttributes;
    if (!email || !email.includes('@')) {
        throw Error('Username does not exists or invalid email address');
    }
    const emailDomain = email?.split('@')[1];
    if (!emailDomain || !allowed_domains) {
        throw new Error('Server error - invalid configuration');
    }
    if (!allowed_domains.includes(emailDomain)) {
        throw new Error('Invalid email address domain');
    }
    return event;
};
