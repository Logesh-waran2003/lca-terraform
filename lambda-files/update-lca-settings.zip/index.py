import boto3
import json

ssm = boto3.client('ssm')

def handler(event, context):
    print(json.dumps(event))
    parameter_name = event.get("LCASettingsName")
    parameter_values = event.get("LCASettingsKeyValuePairs", {})
    try:
        response = ssm.get_parameter(Name=parameter_name)
        settings_json = response['Parameter']['Value']
        settings = json.loads(settings_json)
        print(f"Existing settings: {settings}")
        for key, value in parameter_values.items():
            settings[key] = value
        print(f"Updated settings: {settings}")
        new_settings_json = json.dumps(settings)
        ssm.put_parameter(
            Name=parameter_name,
            Value=new_settings_json,
            Overwrite=True
        )
        print("SSM parameter updated successfully")
        return {"Status": "SUCCESS"}
    except Exception as e:
        print(f"Error updating SSM parameter: {e}")
        raise e
